package com.agon.app.ui.theme

import androidx.compose.ui.graphics.Color

// ════════════════════════════════════════════════════════════════════
// 🎨 Romantic Palette - لوحة ألوان رومانسية
// ════════════════════════════════════════════════════════════════════

// Light Theme - ألوان فاتحة
val RosePrimary = Color(0xFFB8336A)         // وردي غامق - اللون الأساسي
val RoseOnPrimary = Color(0xFFFFF1F5)        // وردي فاتح جداً
val RosePrimaryContainer = Color(0xFFFFD9E4) // حاوية وردية
val RoseOnPrimaryContainer = Color(0xFF3F0019) // نص على الحاوية

val GoldSecondary = Color(0xFFD4AF37)       // ذهبي - لون ثانوي
val GoldOnSecondary = Color(0xFF1F1B08)
val GoldSecondaryContainer = Color(0xFFFFF1C2)
val GoldOnSecondaryContainer = Color(0xFF241B00)

val BurgundyTertiary = Color(0xFF8B1A4B)    // عنابي - لون ثالث
val BurgundyOnTertiary = Color(0xFFFFECF0)
val BurgundyTertiaryContainer = Color(0xFFFFD9E3)
val BurgundyOnTertiaryContainer = Color(0xFF3F0019)

val CreamBackground = Color(0xFFFFF8F5)     // خلفية كريمية
val CreamOnBackground = Color(0xFF21191C)
val CreamSurface = Color(0xFFFFF8F5)
val CreamOnSurface = Color(0xFF21191C)
val CreamSurfaceVariant = Color(0xFFF2DDE0)
val CreamOnSurfaceVariant = Color(0xFF524345)
val CreamOutline = Color(0xFF847375)
val CreamOutlineVariant = Color(0xFFD5C2C5)

val ErrorRed = Color(0xFFBA1A1A)
val OnErrorRed = Color(0xFFFFFFFF)
val ErrorContainerRed = Color(0xFFFFDAD6)
val OnErrorContainerRed = Color(0xFF410002)

// Dark Theme - ألوان داكنة
val RosePrimaryDark = Color(0xFFFFB1C7)      // وردي فاتح للداكن
val RoseOnPrimaryDark = Color(0xFF5E1130)
val RosePrimaryContainerDark = Color(0xFF7B2947)
val RoseOnPrimaryContainerDark = Color(0xFFFFD9E4)

val GoldSecondaryDark = Color(0xFFE6C849)
val GoldOnSecondaryDark = Color(0xFF3D2F00)
val GoldSecondaryContainerDark = Color(0xFF584400)
val GoldOnSecondaryContainerDark = Color(0xFFFFF1C2)

val BurgundyTertiaryDark = Color(0xFFEBB7C7)
val BurgundyOnTertiaryDark = Color(0xFF5E1131)
val BurgundyTertiaryContainerDark = Color(0xFF7B2A41)
val BurgundyOnTertiaryContainerDark = Color(0xFFFFD9E3)

val DarkBackground = Color(0xFF1A1216)      // خلفية داكنة
val DarkOnBackground = Color(0xFFEDE0E3)
val DarkSurface = Color(0xFF1A1216)
val DarkOnSurface = Color(0xFFEDE0E3)
val DarkSurfaceVariant = Color(0xFF524345)
val DarkOnSurfaceVariant = Color(0xFFD7C2C5)
val DarkOutline = Color(0xFFA08C90)
val DarkOutlineVariant = Color(0xFF524345)

// Custom gradient colors - ألوان متدرجة
val HeartGradientStart = Color(0xFFFF6B9D)
val HeartGradientMiddle = Color(0xFFC06C84)
val HeartGradientEnd = Color(0xFF6C5B7B)

val GoldGradientStart = Color(0xFFFFD700)
val GoldGradientEnd = Color(0xFFB8860B)

val NightGradientStart = Color(0xFF2C1810)
val NightGradientEnd = Color(0xFF6B2C5F)
