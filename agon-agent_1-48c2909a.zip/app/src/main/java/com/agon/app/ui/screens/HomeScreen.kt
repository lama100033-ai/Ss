package com.agon.app.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.LoveMessages
import com.agon.app.ui.components.AnimatedHeart
import com.agon.app.ui.components.DecorativeDivider
import com.agon.app.ui.components.FloatingHearts
import com.agon.app.ui.components.MemoryCard
import com.agon.app.ui.components.RomanticGradientHeader
import com.agon.app.ui.components.TwinklingStar
import com.agon.app.ui.theme.HeartGradientEnd
import com.agon.app.ui.theme.HeartGradientMiddle
import com.agon.app.ui.theme.HeartGradientStart
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.temporal.ChronoUnit

@Composable
fun HomeScreen() {
    // رسالة عشوائية متغيرة
    val allMessages = LoveMessages.messages
    var currentMessageIndex by remember { mutableStateOf(0) }

    // تغيير الرسالة كل 6 ثوان
    LaunchedEffect(Unit) {
        while (true) {
            delay(6000)
            currentMessageIndex = (currentMessageIndex + 1) % allMessages.size
        }
    }

    // أيام الحب - عدّاد
    val daysOfLove = remember {
        // تاريخ بداية الحب - قابل للتعديل
        val startDate = LocalDate.of(2020, 1, 1)
        val today = LocalDate.now()
        ChronoUnit.DAYS.between(startDate, today).toInt().coerceAtLeast(1)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // خلفية متدرجة
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.2f),
                        ),
                    ),
                ),
        )

        // قلوب متطايرة
        FloatingHearts(
            modifier = Modifier.fillMaxSize(),
            heartCount = 10,
            primaryColor = MaterialTheme.colorScheme.primary,
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                top = 0.dp,
                bottom = 100.dp,
            ),
        ) {
            // العنوان العلوي
            item {
                RomanticGradientHeader(
                    title = "أسماء يا حبيبتي",
                    subtitle = "To My Love Asma",
                )
            }

            // القلب النابض
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Box(
                        modifier = Modifier
                            .size(200.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        TwinklingStar(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp),
                            size = 28.dp,
                            color = MaterialTheme.colorScheme.secondary,
                        )
                        TwinklingStar(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(8.dp),
                            size = 32.dp,
                            color = MaterialTheme.colorScheme.tertiary,
                        )
                        TwinklingStar(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(8.dp),
                            size = 24.dp,
                            color = MaterialTheme.colorScheme.secondary,
                        )
                        TwinklingStar(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(8.dp),
                            size = 28.dp,
                            color = MaterialTheme.colorScheme.tertiary,
                        )
                        AnimatedHeart(
                            size = 140.dp,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                }
            }

            // اليوم المتغير
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = "💌 رسالة اليوم",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Card مع تأثير التحديث
                    AnimatedContent(
                        targetState = allMessages[currentMessageIndex],
                        transitionSpec = {
                            (fadeIn(animationSpec = tween(700)) + slideInVertically { it / 4 }) togetherWith
                                (fadeOut(animationSpec = tween(500)) + slideOutVertically { -it / 4 })
                        },
                        label = "message",
                    ) { message ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(28.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surface,
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(
                                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                                                MaterialTheme.colorScheme.surface,
                                            ),
                                        ),
                                    ),
                            ) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(54.dp)
                                                .clip(RoundedCornerShape(18.dp))
                                                .background(
                                                    Brush.linearGradient(
                                                        colors = listOf(
                                                            HeartGradientStart,
                                                            HeartGradientMiddle,
                                                            HeartGradientEnd,
                                                        ),
                                                    ),
                                                ),
                                            contentAlignment = Alignment.Center,
                                        ) {
                                            Text(
                                                text = message.emoji,
                                                fontSize = 28.sp,
                                            )
                                        }
                                        Column {
                                            Text(
                                                text = message.category,
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.SemiBold,
                                            )
                                            Text(
                                                text = message.title,
                                                style = MaterialTheme.typography.titleLarge,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                fontWeight = FontWeight.Bold,
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(20.dp))

                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(1.dp)
                                            .background(
                                                Brush.horizontalGradient(
                                                    colors = listOf(
                                                        Color.Transparent,
                                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                                                        Color.Transparent,
                                                    ),
                                                ),
                                            ),
                                    )

                                    Spacer(modifier = Modifier.height(20.dp))

                                    Text(
                                        text = message.message,
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        lineHeight = 32.sp,
                                        textAlign = TextAlign.Start,
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // فاصل
            item {
                Spacer(modifier = Modifier.height(32.dp))
                DecorativeDivider(drawable = "✨")
                Spacer(modifier = Modifier.height(24.dp))
            }

            // أرقام الحب - Love Stats
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    MemoryCard(
                        icon = "💕",
                        value = daysOfLove.toString(),
                        title = "يوماً معاً",
                        subtitle = "Days of Love",
                        modifier = Modifier
                            .weight(1f)
                            .height(140.dp),
                    )
                    MemoryCard(
                        icon = "💌",
                        value = "∞",
                        title = "أحبك دائماً",
                        subtitle = "Love Forever",
                        modifier = Modifier
                            .weight(1f)
                            .height(140.dp),
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    MemoryCard(
                        icon = "🌹",
                        value = "${LoveMessages.reasons.size}",
                        title = "سبباً أحبك",
                        subtitle = "Reasons I Love You",
                        modifier = Modifier
                            .weight(1f)
                            .height(140.dp),
                    )
                    MemoryCard(
                        icon = "✨",
                        value = "12",
                        title = "رسالة لكِ",
                        subtitle = "Messages for You",
                        modifier = Modifier
                            .weight(1f)
                            .height(140.dp),
                    )
                }
            }

            // زر القلب الكبير
            item {
                Spacer(modifier = Modifier.height(32.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Button(
                        onClick = {
                            currentMessageIndex = (currentMessageIndex + 1) % allMessages.size
                        },
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(64.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(28.dp),
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "رسالة جديدة 💕",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
        }
    }
}
