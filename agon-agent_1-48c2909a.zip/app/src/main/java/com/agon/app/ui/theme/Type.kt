package com.agon.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.googlefonts.Font
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.unit.sp
import com.agon.app.R

// ════════════════════════════════════════════════════════════════════
// ✨ Arabic Calligraphy Typography - خطوط عربية أنيقة
// ════════════════════════════════════════════════════════════════════

// Google Fonts Provider for Arabic calligraphy
private val googleFontsProvider = GoogleFont.Provider(
    providerAuthority = "com.google.android.gms.fonts",
    providerPackage = "com.google.android.gms",
    certificates = R.array.com_google_android_gms_fonts_certs
)

// Arabic calligraphy fonts from Google Fonts
val AmiriFont = GoogleFont("Amiri")
val ArefRuqaaFont = GoogleFont("Aref Ruqaa")
val LateefFont = GoogleFont("Lateef")
val ReemKufiFont = GoogleFont("Reem Kufi")
val CairoFont = GoogleFont("Cairo")

// Font families
val AmiriFamily = FontFamily(
    Font(googleFont = AmiriFont, fontProvider = googleFontsProvider, weight = FontWeight.Normal),
    Font(googleFont = AmiriFont, fontProvider = googleFontsProvider, weight = FontWeight.Bold),
    Font(googleFont = AmiriFont, fontProvider = googleFontsProvider, weight = FontWeight.Light)
)

val ArefRuqaaFamily = FontFamily(
    Font(googleFont = ArefRuqaaFont, fontProvider = googleFontsProvider, weight = FontWeight.Normal),
    Font(googleFont = ArefRuqaaFont, fontProvider = googleFontsProvider, weight = FontWeight.Bold)
)

val LateefFamily = FontFamily(
    Font(googleFont = LateefFont, fontProvider = googleFontsProvider, weight = FontWeight.Normal),
    Font(googleFont = LateefFont, fontProvider = googleFontsProvider, weight = FontWeight.Bold)
)

val ReemKufiFamily = FontFamily(
    Font(googleFont = ReemKufiFont, fontProvider = googleFontsProvider, weight = FontWeight.Normal),
    Font(googleFont = ReemKufiFont, fontProvider = googleFontsProvider, weight = FontWeight.Bold),
    Font(googleFont = ReemKufiFont, fontProvider = googleFontsProvider, weight = FontWeight.Light)
)

val CairoFamily = FontFamily(
    Font(googleFont = CairoFont, fontProvider = googleFontsProvider, weight = FontWeight.Normal),
    Font(googleFont = CairoFont, fontProvider = googleFontsProvider, weight = FontWeight.Bold),
    Font(googleFont = CairoFont, fontProvider = googleFontsProvider, weight = FontWeight.SemiBold)
)

// Custom typography for romantic app
val LoveTypography = Typography(
    // Display - للعناوين الكبيرة
    displayLarge = TextStyle(
        fontFamily = ArefRuqaaFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 57.sp,
        lineHeight = 64.sp,
        letterSpacing = (-0.25).sp,
    ),
    displayMedium = TextStyle(
        fontFamily = ArefRuqaaFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 45.sp,
        lineHeight = 52.sp,
    ),
    displaySmall = TextStyle(
        fontFamily = ArefRuqaaFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 36.sp,
        lineHeight = 44.sp,
    ),

    // Headline - للعناوين الفرعية
    headlineLarge = TextStyle(
        fontFamily = AmiriFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 32.sp,
        lineHeight = 40.sp,
    ),
    headlineMedium = TextStyle(
        fontFamily = AmiriFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        lineHeight = 36.sp,
    ),
    headlineSmall = TextStyle(
        fontFamily = AmiriFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        lineHeight = 32.sp,
    ),

    // Title - لعنوان القوائم
    titleLarge = TextStyle(
        fontFamily = CairoFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp,
        lineHeight = 28.sp,
    ),
    titleMedium = TextStyle(
        fontFamily = CairoFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.15.sp,
    ),
    titleSmall = TextStyle(
        fontFamily = CairoFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp,
    ),

    // Body - للمحتوى
    bodyLarge = TextStyle(
        fontFamily = LateefFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 18.sp,
        lineHeight = 28.sp,
        letterSpacing = 0.5.sp,
    ),
    bodyMedium = TextStyle(
        fontFamily = LateefFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.25.sp,
    ),
    bodySmall = TextStyle(
        fontFamily = CairoFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.4.sp,
    ),

    // Label - للأزرار والتسميات
    labelLarge = TextStyle(
        fontFamily = CairoFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp,
    ),
    labelMedium = TextStyle(
        fontFamily = CairoFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.5.sp,
    ),
    labelSmall = TextStyle(
        fontFamily = CairoFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 11.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.5.sp,
    ),
)
