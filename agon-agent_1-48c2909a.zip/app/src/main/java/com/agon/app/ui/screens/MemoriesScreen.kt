package com.agon.app.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.LoveMessages
import com.agon.app.ui.components.AnimatedHeart
import com.agon.app.ui.components.DecorativeDivider
import com.agon.app.ui.components.FloatingHearts
import com.agon.app.ui.components.MemoryCard
import com.agon.app.ui.components.RomanticGradientHeader
import com.agon.app.ui.theme.HeartGradientEnd
import com.agon.app.ui.theme.HeartGradientMiddle
import com.agon.app.ui.theme.HeartGradientStart
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.Period
import java.time.temporal.ChronoUnit
import kotlin.math.absoluteValue

@Composable
fun MemoriesScreen() {
    val reasons = LoveMessages.reasons
    var revealedCount by remember { mutableStateOf(0) }

    // تأثير الكشف التدريجي للأسباب
    LaunchedEffect(Unit) {
        while (revealedCount < reasons.size) {
            delay(150)
            revealedCount = (revealedCount + 1).coerceAtMost(reasons.size)
        }
    }

    // عدّاد الحب
    val startDate = remember { LocalDate.of(2020, 1, 1) }
    val today = remember { LocalDate.now() }
    val days = remember {
        ChronoUnit.DAYS.between(startDate, today).toInt().absoluteValue
    }
    val period = remember {
        Period.between(startDate, today)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // خلفية
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.3f),
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                        ),
                    ),
                ),
        )

        FloatingHearts(
            modifier = Modifier.fillMaxSize(),
            heartCount = 8,
            primaryColor = MaterialTheme.colorScheme.primary,
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp),
        ) {
            item {
                RomanticGradientHeader(
                    title = "ذكريات الحب",
                    subtitle = "Memories of Love",
                )
            }

            // بطاقة الأرقام الكبيرة
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        HeartGradientStart,
                                        HeartGradientMiddle,
                                        HeartGradientEnd,
                                    ),
                                ),
                            ),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text(
                                text = "💕",
                                fontSize = 50.sp,
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "منذ أن أحببتُكِ",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White.copy(alpha = 0.95f),
                                fontWeight = FontWeight.SemiBold,
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            AnimatedCounter(
                                targetValue = days.toFloat(),
                                suffix = " يوماً",
                                color = Color.White,
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                CounterItem(
                                    value = period.years.toString(),
                                    label = "سنة",
                                    color = Color.White,
                                )
                                CounterItem(
                                    value = period.months.toString(),
                                    label = "شهر",
                                    color = Color.White,
                                )
                                CounterItem(
                                    value = period.days.toString(),
                                    label = "يوم",
                                    color = Color.White,
                                )
                                CounterItem(
                                    value = "${days * 24}",
                                    label = "ساعة",
                                    color = Color.White,
                                )
                            }
                        }
                    }
                }
            }

            // أرقام سريعة
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        MemoryCard(
                            icon = "💝",
                            value = "${reasons.size}",
                            title = "سبباً أحبكِ",
                            subtitle = "Reasons",
                            modifier = Modifier
                                .weight(1f)
                                .height(120.dp),
                        )
                        MemoryCard(
                            icon = "🌸",
                            value = "∞",
                            title = "نبضة حب",
                            subtitle = "Heartbeats",
                            modifier = Modifier
                                .weight(1f)
                                .height(120.dp),
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        MemoryCard(
                            icon = "🌹",
                            value = "12",
                            title = "رسالة حب",
                            subtitle = "Messages",
                            modifier = Modifier
                                .weight(1f)
                                .height(120.dp),
                        )
                        MemoryCard(
                            icon = "🌟",
                            value = "1",
                            title = "حبيبة واحدة",
                            subtitle = "My Love",
                            modifier = Modifier
                                .weight(1f)
                                .height(120.dp),
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
                DecorativeDivider(drawable = "💖")
                Spacer(modifier = Modifier.height(16.dp))
            }

            // أسباب الحب
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = "لماذا أحبُكِ يا أسماء",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "ومن كل قلبي بلا حدود",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // قائمة الأسباب
            items(reasons.withIndex().toList(), key = { it.index }) { (index, reason) ->
                val isRevealed = index < revealedCount
                val scale by animateFloatAsState(
                    targetValue = if (isRevealed) 1f else 0.85f,
                    animationSpec = tween(400),
                    label = "scale",
                )
                val alpha by animateFloatAsState(
                    targetValue = if (isRevealed) 1f else 0.3f,
                    animationSpec = tween(400),
                    label = "alpha",
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface,
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                                            Color.Transparent,
                                        ),
                                    ),
                                ),
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp)
                                    .graphicsLayer {
                                        this.alpha = alpha
                                        scaleX = scale
                                        scaleY = scale
                                    },
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                // رقم السبب
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(
                                            Brush.linearGradient(
                                                colors = listOf(
                                                    HeartGradientStart,
                                                    HeartGradientMiddle,
                                                    HeartGradientEnd,
                                                ),
                                            ),
                                        ),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Text(
                                        text = "${index + 1}",
                                        color = Color.White,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                    )
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Text(
                                    text = reason,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.SemiBold,
                                )
                            }
                        }
                    }
                }
            }

            // رسالة ختامية
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                    ),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            text = "والقائمة تطول ولا تنتهي",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "كل يوم معكِ يا أسماء، أجد سبباً جديداً أزيده إلى قائمتي. أنتِ الحب الذي لا ينتهي.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center,
                            lineHeight = 28.sp,
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        AnimatedHeart(
                            size = 80.dp,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CounterItem(
    value: String,
    label: String,
    color: Color,
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineSmall,
            color = color,
            fontWeight = FontWeight.Bold,
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = color.copy(alpha = 0.85f),
        )
    }
}

@Composable
private fun AnimatedCounter(
    targetValue: Float,
    suffix: String,
    color: Color = MaterialTheme.colorScheme.primary,
) {
    var currentValue by remember { mutableStateOf(0f) }
    LaunchedEffect(targetValue) {
        val steps = 60
        val stepDelay = 30L
        repeat(steps) { i ->
            currentValue = targetValue * (i + 1) / steps
            delay(stepDelay)
        }
    }
    Text(
        text = "${currentValue.toInt()}$suffix",
        style = MaterialTheme.typography.displaySmall,
        color = color,
        fontWeight = FontWeight.Bold,
    )
}
