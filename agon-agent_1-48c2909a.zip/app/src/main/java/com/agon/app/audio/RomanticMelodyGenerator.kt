package com.agon.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

// ════════════════════════════════════════════════════════════════════
// 🎵 Romantic Melody Generator - مولّد اللحن الرومانسي
// ════════════════════════════════════════════════════════════════════
//
// توليد لحن رومانسي ناعم باستخدام تركيب الموجات الصوتية
// يعزف مقطعاً لحنياً يشبه ألحان الحب الشرقية
//

class RomanticMelodyGenerator {

    private var audioTrack: AudioTrack? = null
    private var generatorJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var isPlaying = false

    // نوتات اللحن الرومانسي - مقام بيات (شرقي)
    // الترددات بالنوت الموسيقية الشرقية
    private val melodyNotes = listOf(
        // Phrase 1 - جملة لحنية حزينة رومانسية
        Note(523.25f, 800),    // C5 - دو
        Note(587.33f, 600),    // D5 - ري
        Note(659.25f, 800),    // E5 - مي
        Note(523.25f, 600),    // C5 - دو
        Note(440.00f, 1000),   // A4 - لا
        Note(493.88f, 600),    // B4 - سي
        Note(523.25f, 1200),   // C5 - دو

        // Phrase 2 - ارتفاع
        Note(659.25f, 700),    // E5 - مي
        Note(587.33f, 500),    // D5 - ري
        Note(523.25f, 700),    // C5 - دو
        Note(493.88f, 500),    // B4 - سي
        Note(440.00f, 1000),   // A4 - لا
        Note(523.25f, 1500),   // C5 - دو

        // Pause - صمت
        Note(0f, 800),

        // Phrase 3 - تكرار الجملة بتغييرات
        Note(523.25f, 700),
        Note(659.25f, 700),
        Note(783.99f, 700),    // G5 - صول
        Note(659.25f, 500),
        Note(523.25f, 700),
        Note(440.00f, 1000),
        Note(493.88f, 600),
        Note(523.25f, 1500),

        // Pause
        Note(0f, 1000),

        // Phrase 4 - خاتمة
        Note(440.00f, 800),
        Note(493.88f, 600),
        Note(523.25f, 800),
        Note(587.33f, 600),
        Note(659.25f, 1200),
        Note(523.25f, 2000),
    )

    private data class Note(val frequency: Float, val durationMs: Int)

    /**
     * توليد عيّنات صوتية لنوتة واحدة مع تأثير reverb بسيط
     */
    private fun generateToneSamples(frequency: Float, durationMs: Int, sampleRate: Int): FloatArray {
        val numSamples = (durationMs * sampleRate / 1000)
        val samples = FloatArray(numSamples)

        if (frequency > 0) {
            val angularFrequency = 2.0 * PI * frequency
            val attackSamples = (numSamples * 0.05).toInt()  // 5% attack
            val releaseSamples = (numSamples * 0.3).toInt()  // 30% release

            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                // مزيج من الموجة الأساسية + توافقيات لإعطاء صوت غني
                var sample = 0.0
                sample += 0.5 * sin(angularFrequency * t)
                sample += 0.25 * sin(angularFrequency * 2 * t)
                sample += 0.15 * sin(angularFrequency * 3 * t)
                sample += 0.08 * sin(angularFrequency * 4 * t)

                // ADPHR envelope - Attack, Decay, Sustain, Release
                var envelope = 1.0
                if (i < attackSamples) {
                    envelope = i.toDouble() / attackSamples
                } else if (i > numSamples - releaseSamples) {
                    envelope = (numSamples - i).toDouble() / releaseSamples
                }
                samples[i] = (sample * envelope * 0.4).toFloat()  // تخفيض مستوى الصوت
            }
        }
        // إذا التردد = 0 فهي صمت
        return samples
    }

    fun start() {
        if (isPlaying) return
        isPlaying = true

        val sampleRate = 44100
        val bufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_FLOAT
        ).coerceAtLeast(4096) * 4

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        audioTrack?.play()

        generatorJob = scope.launch {
            var repeatIndex = 0
            while (isActive && isPlaying) {
                melodyNotes.forEach { note ->
                    if (!isPlaying) return@forEach
                    val samples = generateToneSamples(note.frequency, note.durationMs, sampleRate)
                    audioTrack?.write(samples, 0, samples.size, AudioTrack.WRITE_BLOCKING)
                }
                repeatIndex++
                // فاصل بين تكرارات اللحن
                if (repeatIndex < 1000) {
                    val silence = FloatArray(sampleRate / 2)  // 0.5 second silence
                    audioTrack?.write(silence, 0, silence.size, AudioTrack.WRITE_BLOCKING)
                }
            }
        }
    }

    fun stop() {
        isPlaying = false
        generatorJob?.cancel()
        generatorJob = null
        audioTrack?.stop()
        audioTrack?.release()
        audioTrack = null
    }

    fun isPlaying() = isPlaying

    fun release() {
        stop()
        scope.cancel()
    }
}
