package com.agon.app.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.audio.RomanticMelodyGenerator
import com.agon.app.data.Songs
import com.agon.app.ui.components.AnimatedHeart
import com.agon.app.ui.components.DecorativeDivider
import com.agon.app.ui.components.FloatingHearts
import com.agon.app.ui.components.RomanticGradientHeader
import com.agon.app.ui.theme.HeartGradientEnd
import com.agon.app.ui.theme.HeartGradientMiddle
import com.agon.app.ui.theme.HeartGradientStart
import kotlin.math.sin

@Composable
fun MusicScreen() {
    val song = Songs.elissaBetmoun
    val melodyGenerator = remember { RomanticMelodyGenerator() }
    var isPlaying by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var currentLyricIndex by remember { mutableStateOf(0) }
    var volume by remember { mutableFloatStateOf(0.7f) }

    // تنظيف عند الخروج
    DisposableEffect(Unit) {
        onDispose {
            melodyGenerator.release()
        }
    }

    // تحديث الوقت والكلمات
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            melodyGenerator.start()
        }
        while (isPlaying) {
            kotlinx.coroutines.delay(1000)
            if (isPlaying) {
                progress = (progress + 1f / song.durationSeconds).coerceAtMost(1f)
                val currentTime = progress * song.durationSeconds
                val newIndex = song.lyrics.indexOfLast { it.time <= currentTime.toInt() }
                if (newIndex >= 0) currentLyricIndex = newIndex
                if (progress >= 1f) {
                    isPlaying = false
                    progress = 0f
                    melodyGenerator.stop()
                }
            }
        }
        if (!isPlaying) melodyGenerator.stop()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // خلفية
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.surface,
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                            MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.3f),
                        ),
                    ),
                ),
        )

        FloatingHearts(
            modifier = Modifier.fillMaxSize(),
            heartCount = 6,
            primaryColor = MaterialTheme.colorScheme.primary,
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp),
        ) {
            item {
                RomanticGradientHeader(
                    title = "أغنية الحب",
                    subtitle = "Song of Love",
                )
            }

            // صورة الألبوم المزيّفة (Rotating disc)
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    // القرص الدوّار
                    Box(
                        modifier = Modifier
                            .size(280.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        val rotation = rememberInfiniteTransition(label = "disc")
                        val angle by rotation.animateFloat(
                            initialValue = 0f,
                            targetValue = 360f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(20000, easing = LinearEasing),
                                repeatMode = RepeatMode.Restart,
                            ),
                            label = "angle",
                        )

                        val actualAngle = if (isPlaying) angle else 0f
                        val animAngle by animateFloatAsState(
                            targetValue = actualAngle,
                            label = "animAngle",
                        )

                        // القرص
                        Box(
                            modifier = Modifier
                                .size(280.dp)
                                .rotate(animAngle),
                            contentAlignment = Alignment.Center,
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val center = Offset(this.size.width / 2, this.size.height / 2)
                                val radius = this.size.width / 2

                                // خلفية القرص
                                drawCircle(
                                    brush = Brush.radialGradient(
                                        colors = listOf(
                                            Color(0xFF2C1810),
                                            Color(0xFF1A0E08),
                                            Color(0xFF000000),
                                        ),
                                        center = center,
                                        radius = radius,
                                    ),
                                )

                                // حلقات تركوازية
                                for (i in 1..5) {
                                    val ringRadius = radius * (1f - i * 0.15f)
                                    drawCircle(
                                        color = Color(0xFF4A2C2A).copy(alpha = 0.6f),
                                        radius = ringRadius,
                                        center = center,
                                    )
                                }

                                // مركز الألبوم
                                drawCircle(
                                    brush = Brush.linearGradient(
                                        colors = listOf(
                                            HeartGradientStart,
                                            HeartGradientMiddle,
                                            HeartGradientEnd,
                                        ),
                                    ),
                                    radius = radius * 0.35f,
                                    center = center,
                                )

                                // النقش المركزي
                                drawCircle(
                                    color = Color.White.copy(alpha = 0.15f),
                                    radius = radius * 0.32f,
                                    center = center,
                                )

                                // الثقب المركزي
                                drawCircle(
                                    color = Color(0xFF1A0E08),
                                    radius = radius * 0.05f,
                                    center = center,
                                )

                                // رمز نوتة موسيقية في المركز
                                drawCircle(
                                    color = Color.White.copy(alpha = 0.5f),
                                    radius = radius * 0.12f,
                                    center = center,
                                )
                            }

                            // النص على القرص
                            Box(
                                modifier = Modifier
                                    .size(120.dp),
                                contentAlignment = Alignment.Center,
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.MusicNote,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(28.dp),
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = song.artist,
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                    )
                                    Text(
                                        text = song.title,
                                        color = Color.White.copy(alpha = 0.85f),
                                        fontSize = 12.sp,
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // معلومات الأغنية
                    Text(
                        text = song.title,
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = song.artist,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = song.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                    )
                }
            }

            // بطاقة الكلمات الحالية
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                                        MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f),
                                    ),
                                ),
                            ),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text(
                                text = "🎤 كلمات الأغنية",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            AnimatedContent(
                                targetState = song.lyrics.getOrNull(currentLyricIndex)?.text ?: "",
                                transitionSpec = {
                                    (fadeIn(tween(700)) + slideInVertically { it / 3 }) togetherWith
                                        (fadeOut(tween(500)) + slideOutVertically { -it / 3 })
                                },
                                label = "lyric",
                            ) { lyric ->
                                Text(
                                    text = lyric,
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    lineHeight = 36.sp,
                                )
                            }
                        }
                    }
                }
            }

            // شريط التقدّم
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                ) {
                    val currentTime = (progress * song.durationSeconds).toInt()
                    val totalTime = song.durationSeconds
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = formatTime(currentTime),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            text = formatTime(totalTime),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Slider(
                        value = progress,
                        onValueChange = { progress = it },
                        modifier = Modifier.fillMaxWidth(),
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = MaterialTheme.colorScheme.primaryContainer,
                        ),
                    )
                }
            }

            // أزرار التحكم
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(
                        onClick = { progress = 0f },
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipPrevious,
                            contentDescription = "Previous",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(32.dp),
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))

                    FilledIconButton(
                        onClick = { isPlaying = !isPlaying },
                        modifier = Modifier.size(72.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                        ),
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Play",
                            tint = Color.White,
                            modifier = Modifier.size(40.dp),
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))

                    IconButton(
                        onClick = { progress = 1f; isPlaying = false },
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Next",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(32.dp),
                        )
                    }
                }
            }

            // Visualizer
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = "🎵 Visualizer",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    MusicVisualizer(
                        isPlaying = isPlaying,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(80.dp),
                    )
                }
            }

            // التحكم بالصوت
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "مستوى الصوت",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                    Slider(
                        value = volume,
                        onValueChange = { volume = it },
                        modifier = Modifier.fillMaxWidth(),
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.secondary,
                            activeTrackColor = MaterialTheme.colorScheme.secondary,
                            inactiveTrackColor = MaterialTheme.colorScheme.secondaryContainer,
                        ),
                    )
                }
            }

            // فاصل
            item {
                Spacer(modifier = Modifier.height(24.dp))
                DecorativeDivider(drawable = "💖")
                Spacer(modifier = Modifier.height(16.dp))

                // رسالة الإهداء
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    ),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            text = "💝 إهداء",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "هذه الأغنية وكلمات الحب فيها، أهداها لكِ يا من تكون حياتي أحلى معكِ. يا أسماء، كل نغمة فيها تذكّرني بحبكِ.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center,
                            lineHeight = 28.sp,
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        AnimatedHeart(
                            size = 60.dp,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun MusicVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
) {
    val transition = rememberInfiniteTransition(label = "viz")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "phase",
    )

    val barCount = 32

    Canvas(modifier = modifier) {
        val w = this.size.width
        val h = this.size.height
        val barWidth = w / barCount - 4f
        val centerY = h / 2

        for (i in 0 until barCount) {
            val normalized = i.toFloat() / barCount
            val amplitude = if (isPlaying) {
                (kotlin.math.sin(phase * 2f + normalized * 4f) * 0.5f + 0.5f) * 0.8f + 0.2f
            } else {
                0.15f + (kotlin.math.sin(normalized * Math.PI.toFloat() * 4f) * 0.5f + 0.5f) * 0.1f
            }
            val barHeight = h * amplitude
            val x = i * (barWidth + 4f)
            val y = (h - barHeight) / 2

            drawRoundRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFFF6B9D),
                        Color(0xFFC06C84),
                        Color(0xFF6C5B7B),
                    ),
                ),
                topLeft = Offset(x, y),
                size = androidx.compose.ui.geometry.Size(barWidth, barHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(15f, 15f),
            )
        }
    }
}

private fun formatTime(seconds: Int): String {
    val mins = seconds / 60
    val secs = seconds % 60
    return "%d:%02d".format(mins, secs)
}
