package com.agon.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/**
 * أيقونة قلب مع نبضات - Animated Heart with pulse
 */
@Composable
fun AnimatedHeart(
    modifier: Modifier = Modifier,
    size: Dp = 100.dp,
    color: Color = Color(0xFFE91E63),
    pulseEnabled: Boolean = true,
) {
    val transition = rememberInfiniteTransition(label = "heart")
    val scale by transition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "heartScale",
    )

    val glowAlpha by transition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.55f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "glowAlpha",
    )

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val w = this.size.width
            val h = this.size.height
            val cx = w / 2
            val cy = h / 2

            // رسم القلب
            val path = Path()
            val s = if (pulseEnabled) scale else 1f
            scale(s, s, pivot = Offset(cx, cy)) {
                // منحنى القلب الكلاسيكي
                path.moveTo(cx, cy + h * 0.3f)
                path.cubicTo(
                    cx + w * 0.6f, cy + h * 0.05f,
                    cx + w * 0.55f, cy - h * 0.5f,
                    cx, cy - h * 0.15f,
                )
                path.cubicTo(
                    cx - w * 0.55f, cy - h * 0.5f,
                    cx - w * 0.6f, cy + h * 0.05f,
                    cx, cy + h * 0.3f,
                )
                path.close()

                // توهج خارجي
                drawPath(
                    path = path,
                    brush = Brush.radialGradient(
                        colors = listOf(
                            color.copy(alpha = glowAlpha * 0.4f),
                            color.copy(alpha = 0f),
                        ),
                        center = Offset(cx, cy),
                        radius = w * 0.8f,
                    ),
                )

                // القلب الأساسي مع تدرج
                drawPath(
                    path = path,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFFFF6B9D),
                            Color(0xFFE91E63),
                            Color(0xFFB8336A),
                        ),
                    ),
                )

                // لمعة
                drawCircle(
                    color = Color.White.copy(alpha = 0.45f),
                    radius = w * 0.08f,
                    center = Offset(cx - w * 0.22f, cy - h * 0.18f),
                )
            }
        }
    }
}

/**
 * قلوب متطايرة - Floating Hearts Background
 */
@Composable
fun FloatingHearts(
    modifier: Modifier = Modifier,
    heartCount: Int = 12,
    primaryColor: Color = Color(0xFFE91E63),
) {
    val transition = rememberInfiniteTransition(label = "floating")

    val offset by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "offset",
    )

    val alpha by transition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.7f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "alpha",
    )

    Canvas(modifier = modifier) {
        val w = this.size.width
        val h = this.size.height

        for (i in 0 until heartCount) {
            val seed = i * 1.3f
            val xBase = (kotlin.math.sin(seed * 17.0).toFloat() * 0.5f + 0.5f) * w
            val yBase = ((offset + seed * 0.13f) % 1f) * h
            val size = (kotlin.math.sin(seed * 11.0).toFloat() * 0.5f + 0.5f) * 18f + 8f

            val localAlpha = (kotlin.math.sin((offset + seed) * 2.0 * Math.PI.toFloat()) * 0.5f + 0.5f) * alpha

            val path = Path()
            val cx = xBase
            val cy = yBase
            path.moveTo(cx, cy + size * 0.3f)
            path.cubicTo(
                cx + size * 0.6f, cy + size * 0.05f,
                cx + size * 0.55f, cy - size * 0.5f,
                cx, cy - size * 0.15f,
            )
            path.cubicTo(
                cx - size * 0.55f, cy - size * 0.5f,
                cx - size * 0.6f, cy + size * 0.05f,
                cx, cy + size * 0.3f,
            )
            path.close()

            drawPath(
                path = path,
                color = primaryColor.copy(alpha = (localAlpha * 0.7f).toFloat()),
            )
        }
    }
}

/**
 * نجمة متلألئة - Twinkling Star
 */
@Composable
fun TwinklingStar(
    modifier: Modifier = Modifier,
    size: Dp = 24.dp,
    color: Color = Color(0xFFD4AF37),
) {
    val transition = rememberInfiniteTransition(label = "star")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "rotation",
    )
    val alpha by transition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "alpha",
    )

    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val cx = w / 2
        val cy = h / 2
        val outerRadius = w * 0.45f
        val innerRadius = w * 0.18f

        rotate(rotation, pivot = Offset(cx, cy)) {
            val path = Path()
            for (i in 0..9) {
                val angle = (i * 36 - 90).toFloat() * Math.PI.toFloat() / 180f
                val r = if (i % 2 == 0) outerRadius else innerRadius
                val x = cx + r * kotlin.math.cos(angle.toDouble()).toFloat()
                val y = cy + r * kotlin.math.sin(angle.toDouble()).toFloat()
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()

            drawPath(
                path = path,
                color = color.copy(alpha = alpha),
            )

            drawPath(
                path = path,
                color = Color.White.copy(alpha = alpha * 0.6f),
                style = Stroke(width = 2f),
            )
        }
    }
}
